/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sjbsdeliverable1;

/**
 *
 * @author Joey
 */
public class Player {
    private int id;
    private Fighter fighters;
    
    public Player(int ID, Fighter Fighters){
        this.id = ID;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Player{" + "id=" + id + '}';
    }

    public Fighter getFighters() {
        return fighters;
    }

    public void setFighters(Fighter fighters) {
        this.fighters = fighters;
    }
    
}
