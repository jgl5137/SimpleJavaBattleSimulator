/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sjbsdeliverable1;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Joey
 */
public class FighterList {
    private ArrayList<Fighter> fighterList;
    
    public FighterList(){
        fighterList = new ArrayList();
        addFightersToList();
    }
    
    private void addFightersToList(){
        getListOfFighters().add(new Fighter("Fighter1", 20, 4, 6, 5, new String[] {"Attack", "Defend", "Dodge", "Special"}));
    }
    
    public ArrayList<Fighter> getListOfFighters(){
        return fighterList;
    }
    
}
