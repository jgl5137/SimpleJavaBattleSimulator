/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sjbsdeliverable1;

import java.util.Arrays;

/**
 *
 * @author Joey
 */
public class Fighter {
    private String name;
    private int healthPoints;
    private int attack;
    private int defense;
    private int speed;
    private String[] moveSet;
    
    public Fighter(String Name, int HP, int ATK, int DEF, int SPD, String[] moves){
        this.name = Name;
        this.healthPoints = HP;
        this.attack = ATK;
        this.defense = DEF;
        this.speed = SPD;
        this.moveSet = moves;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHealthPoints() {
        return healthPoints;
    }

    public void setHealthPoints(int healthPoints) {
        this.healthPoints = healthPoints;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public int getDefense() {
        return defense;
    }

    public void setDefense(int defense) {
        this.defense = defense;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public String[] getMoveSet() {
        return moveSet;
    }

    public void setMoveSet(String[] moveSet) {
        this.moveSet = moveSet;
    }

    @Override
    public String toString() {
        return "Fighter Name: " + name + "\nHP: " + healthPoints + "\nATK: " + attack + "\nDEF: " + defense + "\nSPD: " + speed + "\nMoves: " + Arrays.toString(moveSet);
    }
    
    
}
