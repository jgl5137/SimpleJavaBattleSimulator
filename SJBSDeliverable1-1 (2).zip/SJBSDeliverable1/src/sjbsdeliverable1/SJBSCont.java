/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sjbsdeliverable1;

import java.util.Map;

/**
 *
 * @author Joey
 */
public class SJBSCont {
    private FighterList fighterList;
    private SJBSScreens screens;
    
    public SJBSCont(){
        fighterList = new FighterList();
        screens = new SJBSScreens(this);
        screens.setVisible(true);
    }
    
    public FighterList getFighterList(){
        return fighterList;
    }
    
    public Player getNewPlayer(){
        Player newPlayer = new Player(1, fighterList.getListOfFighters().get(0));
        return newPlayer;
    }
}
