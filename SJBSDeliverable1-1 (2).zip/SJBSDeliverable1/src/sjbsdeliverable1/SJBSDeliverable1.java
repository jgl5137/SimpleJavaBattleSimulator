/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sjbsdeliverable1;

/**
 *Assignment: Deliverable 1 - Simple Java Battle Simulator
 * 
 * Names: Joey Lau and Papa Adams
 * 
 * ID: jgl5137
 * 
 * Criteria: -5 to -100 points (at the grader's or instructor's discretion) 
 * if your submission does not meet all the requirements specified in the assignment.
 * 
 * When I was coding up the project deliverable, I decided that my use of a HashMap
 * wouldn't be the most efficient/effective way of going about linking a Player to a Fighter.
 * What I did instead was add a Fighter as an attribute when making a new Player, which would
 * link a Fighter to a Player. I will most likely implement a better solution in Deliverable 2
 * and I will come up with a different way to incorporate a Map, Set, or Queue in later Deliverables.
 * 
 * Description: Establishes the base MVC shell, along with the base objects that will be passed
 * through the Model, View, and Controller classes. The user can click on the "Start" button on
 * the starting screen and move onto the character select screen. Upon clicking the fighter icon,
 * a new Player will have been created and linked to that Fighter.
 *
 */
public class SJBSDeliverable1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SJBSCont sjbsCont = new SJBSCont();
    }
    
}
