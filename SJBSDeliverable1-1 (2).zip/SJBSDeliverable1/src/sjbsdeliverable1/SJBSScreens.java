/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sjbsdeliverable1;

import java.awt.event.*;
import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.Timer;

/**
 *
 * @author Joey
 */
public class SJBSScreens extends JFrame{
    private final SJBSCont sjbsCont;
    private JPanel titlePanel;
    private JLabel titleLabel;
    private final Font titleFont = new Font("Times New Roman", Font.PLAIN, 50);
    private final Font startButtonFont = new Font("Times New Roman", Font.PLAIN, 25);
    private JPanel startButtonPanel;
    private JButton startButton;
    private JPanel messagePanel;
    private JLabel messageLabel;
    private Timer timer;
    private int timerCount = 3;
    private JPanel fighterSelectPanel;
    private JLabel fighterSelectLabel;
    private ImageIcon imageIcon = new ImageIcon(getClass().getResource("/Images/Gnomed.png"));
    private JPanel fighterButtonPanel;
    private JButton fighterButton1;
    private JPanel fighter1StatsPanel;
    private JTextArea fighter1Stats;
    private JPanel messagePanel2;
    private JLabel messageLabel2;
    
    public SJBSScreens(SJBSCont cont){
        this.sjbsCont = cont;
        startingScreen();
    }
    
    private void startingScreen(){
        setTitle("Simple Java Battle Simulator");
        setSize(800, 600);
        getContentPane().setBackground(Color.black);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        titlePanel = new JPanel();
        titlePanel.setBounds(100, 100, 600, 150);
        titlePanel.setBackground(Color.black);
        
        titleLabel = new JLabel("Simple Java Battle Simulator");
        titleLabel.setForeground(Color.yellow);
        titleLabel.setFont(titleFont);
        
        startButtonPanel = new JPanel();
        startButtonPanel.setBounds(300, 350, 200, 100);
        startButtonPanel.setBackground(Color.black);
        
        startButton = new JButton("START");
        startButton.setBackground(Color.black);
        startButton.setForeground(Color.white);
        startButton.setFont(startButtonFont);
        
        messagePanel = new JPanel();
        messagePanel.setBounds(300, 400, 200, 100);
        messagePanel.setBackground(Color.black);
        
        messageLabel = new JLabel("Let's Go!");
        messageLabel.setForeground(Color.white);
        messageLabel.setFont(startButtonFont);
        messageLabel.setVisible(false);
        
        titlePanel.add(titleLabel);
        startButtonPanel.add(startButton);
        messagePanel.add(messageLabel);
        
        getContentPane().add(titlePanel);
        getContentPane().add(startButtonPanel);
        getContentPane().add(messagePanel);
        
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                messageLabel.setVisible(true);
                timer.start();
            }
        });
        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ev) {
                timerCount--;
                if(timerCount == 0){
                    titlePanel.setVisible(false);
                    startButtonPanel.setVisible(false);
                    messagePanel.setVisible(false);
                    fighterSelectScreen();
                    timer.stop();
                }
            }
        });
        
    }
    
    private void fighterSelectScreen(){
        setTitle("Simple Java Battle Simulator");
        setSize(800, 600);
        getContentPane().setBackground(Color.black);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        fighterSelectPanel = new JPanel();
        fighterSelectPanel.setBounds(100, 25, 600, 75);
        fighterSelectPanel.setBackground(Color.black);
        
        fighterSelectLabel = new JLabel("Character Select");
        fighterSelectLabel.setForeground(Color.white);
        fighterSelectLabel.setFont(titleFont);
        
        fighterButtonPanel = new JPanel();
        fighterButtonPanel.setBounds(100, 100, 200, 125);
        fighterButtonPanel.setBackground(Color.black);
        
        fighterButton1 = new JButton();
        fighterButton1.setIcon(imageIcon);
        fighterButton1.setBackground(Color.black);
        
        
        fighter1StatsPanel = new JPanel();
        fighter1StatsPanel.setBounds(75, 225, 250, 150);
        fighter1StatsPanel.setBackground(Color.black);
        
        fighter1Stats = new JTextArea(5, 5);
        fighter1Stats.setBounds(35, 200, 225, 125);
        fighter1Stats.setEditable(false);
        fighter1Stats.setLineWrap(true);
        fighter1Stats.setOpaque(true);
        fighter1Stats.setText(sjbsCont.getFighterList().getListOfFighters().get(0).toString());
        
        messagePanel2 = new JPanel();
        messagePanel2.setBounds(250, 500, 300, 50);
        messagePanel2.setBackground(Color.black);
        
        messageLabel2 = new JLabel();
        messageLabel2.setForeground(Color.white);
        messageLabel2.setFont(startButtonFont);
        messageLabel2.setVisible(false);
        
        fighterSelectPanel.add(fighterSelectLabel);
        fighterButtonPanel.add(fighterButton1);
        fighter1StatsPanel.add(fighter1Stats);
        messagePanel2.add(messageLabel2);
        
        getContentPane().add(fighterSelectPanel);
        getContentPane().add(fighterButtonPanel);
        getContentPane().add(fighter1StatsPanel);
        getContentPane().add(messagePanel2);
        
        fighterButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent eve) {
                Player newPlayer = sjbsCont.getNewPlayer();
                messageLabel2.setText("Player " + newPlayer.getId() + " chooses " + sjbsCont.getFighterList().getListOfFighters().get(0).getName());
                messageLabel2.setVisible(true);
            }
        });
        
    }
    
}
