/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sjbsdeliverable2;

import java.awt.event.*;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import javax.swing.Timer;

/**
 *
 * @author Joey
 */
public class SJBSViews extends JFrame{
    private final SJBSCont sjbsCont;
    private JPanel titlePanel;
    private JLabel titleLabel;
    private final Font titleFont = new Font("Times New Roman", Font.PLAIN, 50);
    private final Font startButtonFont = new Font("Times New Roman", Font.PLAIN, 25);
    private JPanel startButtonPanel;
    private JButton startButton;
    private JPanel messagePanel;
    private JLabel messageLabel;
    private Timer timer;
    private Timer timer2;
    private int timerCount = 3;
    private int timerCount2 = 3;
    private JPanel fighterSelectPanel;
    private JLabel fighterSelectLabel;
    //////////////////////FIGHTER 1
    private ImageIcon fighter1Pic = new ImageIcon(getClass().getResource("/Images/GnomedSmol.png"));
    private JPanel fighter1Panel;
    private JLabel fighter1Label;
    private JPanel fighter1ButtonPanel;
    private JButton p1ToF1;
    private JButton p2ToF1;
    private JPanel fighter1StatsPanel;
    private JTextArea fighter1Stats;
    //////////////////////FIGHTER 2
    private ImageIcon fighter2Pic = new ImageIcon(getClass().getResource("/Images/thinkingfaceSmol.png"));
    private JPanel fighter2Panel;
    private JLabel fighter2Label;
    private JPanel fighter2ButtonPanel;
    private JButton p1ToF2;
    private JButton p2ToF2;
    private JPanel fighter2StatsPanel;
    private JTextArea fighter2Stats;
    private JPanel messagePanel2;
    private JLabel messageLabel2;
    private JPanel messagePanel3;
    private JLabel messageLabel3;
    private JPanel battleButtonPanel;
    private JButton battleButton;
    private JPanel messagePanel10;
    private JLabel messageLabel10;
    private JPanel player1Panel;
    private JLabel player1Label;
    private JPanel player1MovesPanel;
    private JButton player1Attack;
    private JButton player1Defend;
    private JButton player1Dodge;
    private JButton player1Special;
    private JPanel player2Panel;
    private JLabel player2Label;
    private JPanel player2MovesPanel;
    private JButton player2Attack;
    private JButton player2Defend;
    private JButton player2Dodge;
    private JButton player2Special;
    private JPanel player1HealthBarPanel;
    private JProgressBar player1HealthBar;
    private JPanel player2HealthBarPanel;
    private JProgressBar player2HealthBar;
    private JPanel player1PositionPanel;
    private JLabel player1Position;
    private JPanel player2PositionPanel;
    private JLabel player2Position;
    
    public SJBSViews(SJBSCont cont){
        this.sjbsCont = cont;
        startingScreen();
    }
    
    private void startingScreen(){
        setTitle("Simple Java Battle Simulator");
        setSize(1920, 1080);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        getContentPane().setBackground(Color.black);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        titlePanel = new JPanel();
        titlePanel.setBounds(100, 100, 1200, 150);
        titlePanel.setBackground(Color.black);
        
        titleLabel = new JLabel("Simple Java Battle Simulator");
        titleLabel.setForeground(Color.yellow);
        titleLabel.setFont(titleFont);
        
        startButtonPanel = new JPanel();
        startButtonPanel.setBounds(300, 350, 800, 100);
        startButtonPanel.setBackground(Color.black);
        
        startButton = new JButton("START");
        startButton.setBackground(Color.black);
        startButton.setForeground(Color.white);
        startButton.setFont(startButtonFont);
        
        messagePanel = new JPanel();
        messagePanel.setBounds(300, 400, 800, 100);
        messagePanel.setBackground(Color.black);
        
        messageLabel = new JLabel("Let's Go!");
        messageLabel.setForeground(Color.white);
        messageLabel.setFont(startButtonFont);
        messageLabel.setVisible(false);
        
        titlePanel.add(titleLabel);
        startButtonPanel.add(startButton);
        messagePanel.add(messageLabel);
        
        getContentPane().add(titlePanel);
        getContentPane().add(startButtonPanel);
        getContentPane().add(messagePanel);
        
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                messageLabel.setVisible(true);
                timer.start();
            }
        });
        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ev) {
                timerCount--;
                if(timerCount == 0){
                    titlePanel.setVisible(false);
                    startButtonPanel.setVisible(false);
                    messagePanel.setVisible(false);
                    fighterSelectScreen();
                    timer.stop();
                }
            }
        });
        
    }
    
    private void fighterSelectScreen(){
        setTitle("Simple Java Battle Simulator");
        setSize(1920, 1080);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        getContentPane().setBackground(Color.black);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        fighterSelectPanel = new JPanel();
        fighterSelectPanel.setBounds(100, 25, 1200, 75);
        fighterSelectPanel.setBackground(Color.black);
        
        fighterSelectLabel = new JLabel("Character Select");
        fighterSelectLabel.setForeground(Color.white);
        fighterSelectLabel.setFont(titleFont);
        
        //////////////////////FIGHTER 1
        fighter1Panel = new JPanel();
        fighter1Panel.setBounds(100, 100, 200, 125);
        fighter1Panel.setBackground(Color.black);
        fighter1Label = new JLabel(fighter1Pic);
        
        fighter1ButtonPanel = new JPanel();
        fighter1ButtonPanel.setBounds(50, 350, 300, 125);
        fighter1ButtonPanel.setBackground(Color.black);
        
        p1ToF1 = new JButton("Assign to Player 1");
        p1ToF1.setBackground(Color.black);
        p1ToF1.setForeground(Color.white);
        p1ToF1.setFont(startButtonFont);
        
        p2ToF1 = new JButton("Assign to Player 2");
        p2ToF1.setBackground(Color.black);
        p2ToF1.setForeground(Color.white);
        p2ToF1.setFont(startButtonFont);
        p2ToF1.setEnabled(false);
        
        fighter1StatsPanel = new JPanel();
        fighter1StatsPanel.setBounds(75, 225, 250, 150);
        fighter1StatsPanel.setBackground(Color.black);
        
        fighter1Stats = new JTextArea(5, 5);
        fighter1Stats.setBounds(35, 200, 225, 125);
        fighter1Stats.setEditable(false);
        fighter1Stats.setLineWrap(true);
        fighter1Stats.setOpaque(true);
        fighter1Stats.setText(sjbsCont.model().getListOfFighters().get(0).toString());
        
        ///////////////////////FIGHTER 2
        fighter2Panel = new JPanel();
        fighter2Panel.setBounds(425, 100, 200, 125);
        fighter2Panel.setBackground(Color.black);
        fighter2Label = new JLabel(fighter2Pic);
        
        fighter2ButtonPanel = new JPanel();
        fighter2ButtonPanel.setBounds(375, 350, 300, 125);
        fighter2ButtonPanel.setBackground(Color.black);
        
        p1ToF2 = new JButton("Assign to Player 1");
        p1ToF2.setBackground(Color.black);
        p1ToF2.setForeground(Color.white);
        p1ToF2.setFont(startButtonFont);
        
        p2ToF2 = new JButton("Assign to Player 2");
        p2ToF2.setBackground(Color.black);
        p2ToF2.setForeground(Color.white);
        p2ToF2.setFont(startButtonFont);
        p2ToF2.setEnabled(false);
        
        fighter2StatsPanel = new JPanel();
        fighter2StatsPanel.setBounds(400, 225, 250, 150);
        fighter2StatsPanel.setBackground(Color.black);
        
        fighter2Stats = new JTextArea(5, 5);
        fighter2Stats.setBounds(400, 200, 225, 125);
        fighter2Stats.setEditable(false);
        fighter2Stats.setLineWrap(true);
        fighter2Stats.setOpaque(true);
        fighter2Stats.setText(sjbsCont.model().getListOfFighters().get(1).toString());
        
        messagePanel2 = new JPanel();
        messagePanel2.setBounds(500, 500, 400, 50);
        messagePanel2.setBackground(Color.black);
        
        messageLabel2 = new JLabel();
        messageLabel2.setForeground(Color.white);
        messageLabel2.setFont(startButtonFont);
        messageLabel2.setVisible(false);
        
        messagePanel3 = new JPanel();
        messagePanel3.setBounds(500, 550, 400, 50);
        messagePanel3.setBackground(Color.black);
        
        messageLabel3 = new JLabel();
        messageLabel3.setForeground(Color.white);
        messageLabel3.setFont(startButtonFont);
        messageLabel3.setVisible(false);
        
        battleButtonPanel = new JPanel();
        battleButtonPanel.setBounds(600, 600, 200, 50);
        battleButtonPanel.setBackground(Color.black);
        
        battleButton = new JButton("Battle");
        battleButton.setBackground(Color.black);
        battleButton.setForeground(Color.white);
        battleButton.setFont(startButtonFont);
        battleButton.setEnabled(false);
        
        
        messagePanel10 = new JPanel();
        messagePanel10.setBounds(550, 650, 300, 50);
        messagePanel10.setBackground(Color.black);
        
        messageLabel10 = new JLabel();
        messageLabel10.setForeground(Color.white);
        messageLabel10.setFont(startButtonFont);
        messageLabel10.setVisible(false);
        
        fighterSelectPanel.add(fighterSelectLabel);
        fighter1Panel.add(fighter1Label);
        fighter1ButtonPanel.add(p1ToF1);
        fighter1ButtonPanel.add(p2ToF1);
        fighter1StatsPanel.add(fighter1Stats);
        fighter2Panel.add(fighter2Label);
        fighter2ButtonPanel.add(p1ToF2);
        fighter2ButtonPanel.add(p2ToF2);
        fighter2StatsPanel.add(fighter2Stats);
        messagePanel2.add(messageLabel2);
        messagePanel3.add(messageLabel3);
        battleButtonPanel.add(battleButton);
        messagePanel10.add(messageLabel10);
        
        getContentPane().add(fighterSelectPanel);
        getContentPane().add(fighter1Panel);
        getContentPane().add(fighter1ButtonPanel);
        getContentPane().add(fighter1StatsPanel);
        getContentPane().add(fighter2Panel);
        getContentPane().add(fighter2ButtonPanel);
        getContentPane().add(fighter2StatsPanel);
        getContentPane().add(messagePanel2);
        getContentPane().add(messagePanel3);
        getContentPane().add(battleButtonPanel);
        getContentPane().add(messagePanel10);
        
        p1ToF1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent eve) {
                Player newPlayer = sjbsCont.player1ToFighter1();
                messageLabel2.setText("Player " + newPlayer.getId() + " chooses " + sjbsCont.model().getListOfFighters().get(0).getName());
                messageLabel2.setVisible(true);
                p1ToF1.setEnabled(false);
                p1ToF2.setEnabled(false);
                p2ToF1.setEnabled(true);
                p2ToF2.setEnabled(true);
            }
        });
        
        p2ToF1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent even) {
                Player newPlayer = sjbsCont.player2ToFighter1();
                messageLabel3.setText("Player " + newPlayer.getId() + " chooses " + sjbsCont.model().getListOfFighters().get(0).getName());
                messageLabel3.setVisible(true);
                p2ToF1.setEnabled(false);
                p2ToF2.setEnabled(false);
                battleButton.setEnabled(true);
            }
        });
        
        p1ToF2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent even) {
                Player newPlayer = sjbsCont.player1ToFighter2();
                messageLabel2.setText("Player " + newPlayer.getId() + " chooses " + sjbsCont.model().getListOfFighters().get(1).getName());
                messageLabel2.setVisible(true);
                p1ToF2.setEnabled(false);
                p1ToF1.setEnabled(false);
                p2ToF1.setEnabled(true);
                p2ToF2.setEnabled(true);
            }
        });
        
        p2ToF2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent even) {
                Player newPlayer = sjbsCont.player2ToFighter2();
                messageLabel3.setText("Player " + newPlayer.getId() + " chooses " + sjbsCont.model().getListOfFighters().get(1).getName());
                messageLabel3.setVisible(true);
                p2ToF2.setEnabled(false);
                p2ToF1.setEnabled(false);
                battleButton.setEnabled(true);
            }
        });
        
        battleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                messageLabel10.setText("Let's Battle!");
                messageLabel10.setVisible(true);
                timer2.start();
            }
        });
        
        timer2 = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent eventL) {
                timerCount2--;
                if(timerCount2 == 0){
                    fighterSelectPanel.setVisible(false);
                    fighter1Panel.setVisible(false);
                    fighter1ButtonPanel.setVisible(false);
                    fighter1StatsPanel.setVisible(false);
                    fighter2Panel.setVisible(false);
                    fighter2ButtonPanel.setVisible(false);
                    fighter2StatsPanel.setVisible(false);
                    messagePanel2.setVisible(false);
                    messagePanel3.setVisible(false);
                    battleButtonPanel.setVisible(false);
                    messagePanel10.setVisible(false);
                    battleScreen();
                    System.out.println(sjbsCont.model().getListOfPlayers());
                    timer2.stop();
                }
            }
        });
    }
    
    private void battleScreen(){
        setTitle("Simple Java Battle Simulator");
        setSize(1920, 1080);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        getContentPane().setBackground(Color.black);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        
        sjbsCont.startBattle(sjbsCont.model().getListOfPlayers().get(0), sjbsCont.model().getListOfPlayers().get(1));
        
        player1MovesPanel = new JPanel();
        player1MovesPanel.setBounds(150, 500, 300, 100);
        player1MovesPanel.setBackground(Color.black);
        player1MovesPanel.setBorder(BorderFactory.createLineBorder(Color.white));
        
        player1Attack = new JButton("Attack");
        player1Attack.setFont(startButtonFont);
        
        player1Defend = new JButton("Defend");
        player1Defend.setFont(startButtonFont);
        
        player1Dodge = new JButton("Dodge");
        player1Dodge.setFont(startButtonFont);
        
        player1Special = new JButton("Special");
        player1Special.setFont(startButtonFont);
        
        player2MovesPanel = new JPanel();
        player2MovesPanel.setBounds(600, 500, 300, 100);
        player2MovesPanel.setBackground(Color.black);
        player2MovesPanel.setBorder(BorderFactory.createLineBorder(Color.white));
        
        player2Attack = new JButton("Attack");
        player2Attack.setFont(startButtonFont);
        player2Attack.setEnabled(false);
        
        player2Defend = new JButton("Defend");
        player2Defend.setFont(startButtonFont);
        
        player2Dodge = new JButton("Dodge");
        player2Dodge.setFont(startButtonFont);
        
        player2Special = new JButton("Special");
        player2Special.setFont(startButtonFont);
        
        player1HealthBarPanel = new JPanel();
        player1HealthBarPanel.setBounds(200, 100, 200, 30);
        player1HealthBarPanel.setBackground(Color.black);
        
        player1HealthBar = new JProgressBar(0, sjbsCont.model().getListOfPlayers().get(0).getFighters().getHealthPoints());
        player1HealthBar.setPreferredSize(new Dimension(200, 30));
        player1HealthBar.setBackground(Color.red);
        player1HealthBar.setForeground(Color.green);
        player1HealthBar.setValue(sjbsCont.model().getListOfPlayers().get(0).getFighters().getHealthPoints());
        
        player2HealthBarPanel = new JPanel();
        player2HealthBarPanel.setBounds(650, 100, 200, 30);
        player2HealthBarPanel.setBackground(Color.black);
        
        player2HealthBar = new JProgressBar(0, sjbsCont.model().getListOfPlayers().get(1).getFighters().getHealthPoints());
        player2HealthBar.setPreferredSize(new Dimension(200, 30));
        player2HealthBar.setBackground(Color.red);
        player2HealthBar.setForeground(Color.green);
        player2HealthBar.setValue(sjbsCont.model().getListOfPlayers().get(1).getFighters().getHealthPoints());
        
        player1PositionPanel = new JPanel();
        player1PositionPanel.setBounds(200, 600, 200, 100);
        player1PositionPanel.setBackground(Color.black);
        
        player1Position = new JLabel();
        player1Position.setForeground(Color.white);
        player1Position.setFont(startButtonFont);
        player1Position.setVisible(false);
        
        player2PositionPanel = new JPanel();
        player2PositionPanel.setBounds(650, 600, 200, 100);
        player2PositionPanel.setBackground(Color.black);
        
        player2Position = new JLabel();
        player2Position.setForeground(Color.white);
        player2Position.setFont(startButtonFont);
        player2Position.setVisible(false);
        
        player1MovesPanel.add(player1Attack);
        player1MovesPanel.add(player1Defend);
        player1MovesPanel.add(player1Dodge);
        player1MovesPanel.add(player1Special);
        player2MovesPanel.add(player2Attack);
        player2MovesPanel.add(player2Defend);
        player2MovesPanel.add(player2Dodge);
        player2MovesPanel.add(player2Special);
        player1HealthBarPanel.add(player1HealthBar);
        player2HealthBarPanel.add(player2HealthBar);
        player1PositionPanel.add(player1Position);
        player2PositionPanel.add(player2Position);
        
        getContentPane().add(player1MovesPanel);
        getContentPane().add(player2MovesPanel);
        getContentPane().add(player1HealthBarPanel);
        getContentPane().add(player2HealthBarPanel);
        getContentPane().add(player1PositionPanel);
        getContentPane().add(player2PositionPanel);
        
        player1Attack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent eventLi) {
                if(sjbsCont.getBattle().isPlayer1Turn()){
                    sjbsCont.model().getListOfPlayers().get(0).attack(sjbsCont.model().getListOfPlayers().get(0), sjbsCont.model().getListOfPlayers().get(1));
                    System.out.println(sjbsCont.model().getListOfPlayers().get(1).getFighters().getName() + "'s health is: " + sjbsCont.model().getListOfPlayers().get(1).getFighters().getHealthPoints());
                    System.out.println("-----------------------------------");
                    player2HealthBar.setValue(sjbsCont.model().getListOfPlayers().get(1).getFighters().getHealthPoints());
                    player1Attack.setEnabled(false);
                    player2Attack.setEnabled(true);
                    sjbsCont.getBattle().switchPlayer();
                }
            }
        });
        
        player2Attack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent eventLi) {
                if(!sjbsCont.getBattle().isPlayer1Turn()){
                    sjbsCont.model().getListOfPlayers().get(1).attack(sjbsCont.model().getListOfPlayers().get(1), sjbsCont.model().getListOfPlayers().get(0));
                    System.out.println(sjbsCont.model().getListOfPlayers().get(0).getFighters().getName() + "'s health is: " + sjbsCont.model().getListOfPlayers().get(0).getFighters().getHealthPoints());
                    System.out.println("-----------------------------------");
                    player1HealthBar.setValue(sjbsCont.model().getListOfPlayers().get(0).getFighters().getHealthPoints());
                    player2Attack.setEnabled(false);
                    player1Attack.setEnabled(true);
                    sjbsCont.getBattle().switchPlayer();
                }
            }
        });
        
        if(sjbsCont.getBattle().getPlayer1().getFighters() == sjbsCont.model().getListOfFighters().get(0)){
            player1Position.setText("Player " + sjbsCont.getBattle().getPlayer1().getId());
            player1Position.setVisible(true);
            player1Panel = new JPanel();
            player1Panel.setBounds(200, 250, 200, 125);
            player1Panel.setBackground(Color.black);
            player1Label = new JLabel(fighter1Pic);
            player1Panel.add(player1Label);
            getContentPane().add(player1Panel);
        }
        
        else{
            player1Position.setText("Player " + sjbsCont.getBattle().getPlayer1().getId());
            player1Position.setVisible(true);
            player1Panel = new JPanel();
            player1Panel.setBounds(200, 250, 200, 125);
            player1Panel.setBackground(Color.black);
            player1Label = new JLabel(fighter2Pic);
            player1Panel.add(player1Label);
            getContentPane().add(player1Panel);
        }
        
        if(sjbsCont.getBattle().getPlayer2().getFighters() == sjbsCont.model().getListOfFighters().get(0)){
            player2Position.setText("Player " + sjbsCont.getBattle().getPlayer2().getId());
            player2Position.setVisible(true);
            player2Panel = new JPanel();
            player2Panel.setBounds(650, 250, 200, 125);
            player2Panel.setBackground(Color.black);
            player2Label = new JLabel(fighter1Pic);
            player2Panel.add(player2Label);
            getContentPane().add(player2Panel);
        }
        
        else{
            player2Position.setText("Player " + sjbsCont.getBattle().getPlayer2().getId());
            player2Position.setVisible(true);
            player2Panel = new JPanel();
            player2Panel.setBounds(650, 250, 200, 125);
            player2Panel.setBackground(Color.black);
            player2Label = new JLabel(fighter2Pic);
            player2Panel.add(player2Label);
            getContentPane().add(player2Panel);
        }
    }
}
