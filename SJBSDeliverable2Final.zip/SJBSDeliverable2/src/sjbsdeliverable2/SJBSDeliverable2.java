/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sjbsdeliverable2;

/**
 *Assignment: Deliverable 2 - Simple Java Battle Simulator
 * 
 * Names: Joey Lau
 * 
 * ID: jgl5137
 * 
 * Description: Simple Java Battle Simulator is a turn-based fighting game where two players choose their
 *              fighter and battle them. When it is time to fight, the 'Battle' screen is displayed and shows each player's
 *              chosen fighter. Players can command their fighter to attack the opposing fighter.
 * 
 * Promised new functionality #1: Implement the first iteration of a turn-based game-loop
 * 
 * To test: When you reach the 'Battle' screen, Player 1's "Attack" button is enabled
 *          and Player 2's "Attack" button is disabled. After clicking on Player 1's
 *          "Attack" button, it will be disabled and Player 2's "Attack" button is enabled.
 *          This signifies that the turn has switched from Player 1 to Player 2 and vice versa.
 *
 * Promised new functionality #2: Implement the 'Attack' functionality
 * 
 * To test: On the 'Battle' screen, if you click on either Player's "Attack" button, the
 *          opponent's health goes down, which is visualized by the health bar above the player's fighter.
 *          At the start, both fighters are at full health (fully green) and after being attacked the
 *          a red color begins to take over the health bar. Once the bar is fully red, the fighter is considered dead.
 *          The damage logs can also be seen in the command line space with each successful attack.
 *          The other actions like 'Defend', 'Dodge', and 'Special' will be implemented in deliverable 3.
 * 
 * Promised new functionality #3: Creation of a 'Battle' screen and it's UI components
 * 
 * To test: When you are on the 'Character Select' screen, you must first pick which fighter Player 1 gets,
 *          then pick which fighter Player 2 gets (make sure both players don't have the same fighter). 
 *          Messages will pop-up signifying that the player has chosen that specific fighter. After both
 *          players have chosen a fighter, the "Battle" button will be enabled. Clicking the "Battle" button
 *          displays a message to confirm that the button works and then will throw up the 'Battle' screen
 *          as the main display, along with it's other UI components.
 * 
 * Promised new functionality #4: Adding more fighters and buttons to the 'Character Select' screen
 * 
 * To test: After clicking on the "Start" button on the 'title' screen, the 'Character Select' screen is displayed
 *          The 'Character Select' screen has new buttons to assign a player to a specified fighter and a new 'Battle'
 *          button is added to the bottom of the screen. All of these buttons display a message after being clicked
 *          to show that they are working as intended.
 */
public class SJBSDeliverable2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SJBSCont sjbsCont = new SJBSCont();
    }
    
}
