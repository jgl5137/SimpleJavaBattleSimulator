/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sjbsdeliverable2;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Joey
 */
public class SJBSModel {
    private ArrayList<Fighter> fighterList;
    private ArrayList<Player> playerList;
    
    public SJBSModel(){
        fighterList = new ArrayList();
        playerList = new ArrayList();
        addFightersToList();
    }
    
    private void addFightersToList(){
        getListOfFighters().add(new Fighter("Gnome", 20, 9, 3, 5, new String[] {"Attack", "Defend", "Dodge", "Special"}));
        getListOfFighters().add(new Fighter("Thinking Emoji", 18, 6, 4, 4, new String[] {"Attack", "Defend", "Dodge", "Special"}));
    }
    
    public ArrayList<Fighter> getListOfFighters(){
        return fighterList;
    }
    
    public void addPlayerToBattle(Player player){
        getListOfPlayers().add(player);
    }
    
    public ArrayList<Player> getListOfPlayers(){
        return playerList;
    }
}
