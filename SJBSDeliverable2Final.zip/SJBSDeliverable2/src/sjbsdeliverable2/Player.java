/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sjbsdeliverable2;

/**
 *
 * @author Joey
 */
public class Player {
    private int id;
    private Fighter fighters;
    
    public Player(int ID, Fighter Fighters){
        this.id = ID;
        this.fighters = Fighters;
    }
    
    public void attack(Player attacker, Player defender){
        int damage = Math.max(0, attacker.getFighters().getAttack() - defender.getFighters().getDefense());
        int health = defender.getFighters().getHealthPoints() - damage;
        
        System.out.println("Damage Done: " + damage);
        
        defender.getFighters().setHealthPoints(health);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Player ID " + id + fighters + "\n";
    }

    public Fighter getFighters() {
        return fighters;
    }

    public void setFighters(Fighter fighters) {
        this.fighters = fighters;
    }
    
}
