/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sjbsdeliverable2;

import java.util.Map;

/**
 *
 * @author Joey
 */
public class SJBSCont {
    private SJBSModel models;
    private SJBSViews views;
    private Battle battle;
    
    public SJBSCont(){
        models = new SJBSModel();
        views = new SJBSViews(this);
        views.setVisible(true);
    }
    
    public SJBSModel model(){
        return models;
    }
    
    public Player player1ToFighter1(){
        Player newPlayer = new Player(1, models.getListOfFighters().get(0));
        models.addPlayerToBattle(newPlayer);
        return newPlayer;
    }
    
    public Player player2ToFighter1(){
        Player newPlayer = new Player(2, models.getListOfFighters().get(0));
        models.addPlayerToBattle(newPlayer);
        return newPlayer;
    }
    
    public Player player1ToFighter2(){
        Player newPlayer = new Player(1, models.getListOfFighters().get(1));
        models.addPlayerToBattle(newPlayer);
        return newPlayer;
    }
    
    public Player player2ToFighter2(){
        Player newPlayer = new Player(2, models.getListOfFighters().get(1));
        models.addPlayerToBattle(newPlayer);
        return newPlayer;
    }
    
    public void startBattle(Player player1, Player player2){
        battle = new Battle(player1, player2);
    }
    
    public Battle getBattle(){
        return battle;
    }
}
