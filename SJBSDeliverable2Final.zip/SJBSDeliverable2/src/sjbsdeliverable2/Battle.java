/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sjbsdeliverable2;

/**
 *
 * @author Joey
 */
public class Battle {
    private Player player1;
    private Player player2;
    private boolean player1Turn = true;
    
    public Battle(Player fighter1, Player fighter2){
        this.player1 = fighter1;
        this.player2 = fighter2;
    }
    
    public void switchPlayer(){
        player1Turn = !player1Turn;
    }

    public boolean isPlayer1Turn() {
        return player1Turn;
    }

    public void setPlayer1Turn(boolean player1Turn) {
        this.player1Turn = player1Turn;
    }

    public Player getPlayer1() {
        return player1;
    }

    public Player getPlayer2() {
        return player2;
    }
    
    
}
